# @metaupspace/design-tokens

Single source of truth for the UpSpace Labs design system — color, typography, spacing, radius, shadow, z-index, and motion tokens, plus the Tailwind CSS preset and CSS custom properties built from them.

## Installation

```sh
npm install @metaupspace/design-tokens
```

> Requires a GitHub Packages token — see the [root README](../../README.md#github-packages-authentication).

## Usage

### CSS variables

In your root layout / global CSS entry point:

```ts
import '@metaupspace/design-tokens/css';
```

### Tailwind preset

```ts
// tailwind.config.ts
import { upspacePreset } from '@metaupspace/design-tokens/tailwind-preset';

export default {
  presets: [upspacePreset],
  content: ['./src/**/*.{ts,tsx}'],
};
```

### TypeScript tokens

```ts
import { primary, spacing, shadows } from '@metaupspace/design-tokens';

console.log(primary[600]); // '#4F46E5'
```

## Exports

| Path | Description |
|---|---|
| `@metaupspace/design-tokens` | TypeScript token objects |
| `@metaupspace/design-tokens/css` | Pre-built CSS custom properties |
| `@metaupspace/design-tokens/tailwind-preset` | Tailwind CSS preset |

## Development

```sh
# Regenerate CSS variables then build
npm run build -w @metaupspace/design-tokens

# Regenerate CSS only
npm run generate:css -w @metaupspace/design-tokens

# Watch
npm run dev -w @metaupspace/design-tokens
```

## License

MIT — see [LICENSE](../../LICENSE).
