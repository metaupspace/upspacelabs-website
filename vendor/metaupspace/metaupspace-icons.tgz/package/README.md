# @metaupspace/icons

A typed React icon library for the UpSpace Labs design system — **4,107 icons**, generated from SVG sources via [SVGR](https://react-svgr.com/), in a single tree-shakable package. The API is intentionally close to [lucide-react](https://lucide.dev/): every icon is a plain React component accepting `size`, `color`, and `strokeWidth`.

```tsx
import { ChevronLeft, Home01, UserAdd01 } from '@metaupspace/icons';

<ChevronLeft />
<Home01 size={20} />
<UserAdd01 color="red" />
<ChevronLeft strokeWidth={1.5} />
```

## Installation

```sh
npm install @metaupspace/icons
```

> Requires a GitHub Packages token — see the [root README](../../README.md#github-packages-authentication).

### Workspace reference (in this monorepo)

```json
{
  "dependencies": {
    "@metaupspace/icons": "^0.1.0"
  }
}
```

then `npm install`.

## Usage

Every icon is a named export, PascalCased from its source filename:

```tsx
import { Home01, Settings2, ArrowLeft } from '@metaupspace/icons';

function Sidebar() {
  return (
    <nav>
      <Home01 />
      <Settings2 />
      <ArrowLeft />
    </nav>
  );
}
```

Icons have no client-side state (no hooks, no effects) and render fine in React Server Components. `IconGallery` *does* need a `'use client'` boundary and already declares it.

### Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `size` | `number` | `24` | Width/height in pixels |
| `color` | `string` | `"currentColor"` | Sets CSS `color` — paths inherit via `stroke="currentColor"` |
| `strokeWidth` | `number` | `2` | Stroke weight across the whole icon |
| `className`, `style`, `onClick`, … | — | — | All standard SVG attributes forwarded to the root `<svg>` |

Every icon also forwards a `ref` to its root `<svg>` element.

## Searching

`searchIcons()` searches by name, tag, and category, with a fuzzy fallback:

```tsx
import { searchIcons, listCategories } from '@metaupspace/icons';

searchIcons('arrow');                              // every arrow-* icon
searchIcons('user', { category: 'Users' });        // scoped to a category
searchIcons('chvrn');                              // fuzzy-matches "chevron-*"
```

Results are `IconMetadata & { score: number }`, sorted best-match first.

## The `IconGallery` component

A drop-in searchable icon browser — search, category filter, and copy-to-clipboard (name / import / JSX):

```tsx
import { IconGallery } from '@metaupspace/icons';

<IconGallery />
<IconGallery defaultCategory="Payments" iconSize={32} />
```

## Regenerating the icon set

```sh
npm run icons:pipeline -w @metaupspace/icons
# or individually:
npm run icons:extract -w @metaupspace/icons
npm run icons:generate -w @metaupspace/icons
npm run icons:metadata -w @metaupspace/icons
```

## Development

```sh
# Build
npm run build -w @metaupspace/icons

# Watch
npm run dev -w @metaupspace/icons

# Tests
npm run test -w @metaupspace/icons

# Type-check
npm run typecheck -w @metaupspace/icons
```

## License

MIT — see [LICENSE](../../LICENSE).
