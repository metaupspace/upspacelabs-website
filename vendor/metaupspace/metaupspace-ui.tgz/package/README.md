# @metaupspace/ui

UpSpace Labs React component library — 23 component families built on design tokens, Tailwind CSS, and Radix UI primitives.

## Installation

```sh
npm install @metaupspace/ui
```

> Requires a GitHub Packages token — see the [root README](../../README.md#github-packages-authentication).

## Setup

**1. Load CSS variables and base styles** in your root layout:

```ts
import '@metaupspace/ui/styles.css';
import '@metaupspace/ui/base.css';
```

**2. Add the Tailwind preset** to your config:

```ts
// tailwind.config.ts
import uiPreset from '@metaupspace/ui/tailwind-preset';

export default {
  presets: [uiPreset],
  content: ['./src/**/*.{ts,tsx}'],
};
```

## Usage

```tsx
import { Button, Input, Modal, Badge } from '@metaupspace/ui';

export function Example() {
  return (
    <div>
      <Button variant="primary" size="md">Save</Button>
      <Badge variant="success">Active</Badge>
      <Input placeholder="Search…" />
    </div>
  );
}
```

## Components

| Family | Components |
|---|---|
| Alert | `Alert` |
| Badge | `Badge` |
| Breadcrumbs | `Breadcrumbs`, `BreadcrumbItem` |
| Button | `Button` |
| Carousel | `Carousel` |
| Chart | `Chart`, `LineChart`, `BarChart` … |
| ColorPicker | `ColorPicker` |
| Dropdown | `Dropdown`, `DropdownItem` |
| FileDropper | `FileDropper` |
| Input | `Input`, `TextArea` |
| Message | `Message` |
| Modal | `Modal` |
| Pagination | `Pagination` |
| ProgressBar | `ProgressBar` |
| RadioGroup | `RadioGroup`, `RadioItem` |
| Select | `Select`, `SelectItem` |
| Slider | `Slider` |
| Table | `Table`, `TableRow`, `TableCell` |
| Toggle | `Toggle` |
| Tooltip | `Tooltip` |
| VideoPlayer | `VideoPlayer` |

## Storybook

```sh
npm run storybook -w @metaupspace/ui
```

## Development

```sh
# Build
npm run build -w @metaupspace/ui

# Watch
npm run dev -w @metaupspace/ui

# Tests
npm run test -w @metaupspace/ui

# Type-check
npm run typecheck -w @metaupspace/ui
```

## License

MIT — see [LICENSE](../../LICENSE).
